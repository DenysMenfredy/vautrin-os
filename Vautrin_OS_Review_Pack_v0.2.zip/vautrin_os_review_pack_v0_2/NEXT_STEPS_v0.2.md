# Vautrin OS - Next Implementation Plan

## Gate A - Close authentication/security foundation

### VOS-037 [P0] Atomic refresh-token rotation
- Make predecessor consumption atomic.
- Add concurrent refresh integration test.
- Assert only one successor can be redeemed.
- Preserve reuse-detection semantics.

### VOS-038 [P0] Preserve active tenant across refresh
- Add `active_tenant_id` to the refresh-session model.
- Verify membership before persisting/switching it.
- Rotate the selected tenant into successor refresh records.
- Add multi-membership refresh E2E coverage.

### VOS-039 [P0] Secure membership revocation use case
- Revoke membership.
- Revoke affected refresh sessions/families.
- Audit the action.
- Add integration coverage.

### VOS-027 [P1] Authentication abuse controls
- Rate-limit login and refresh.
- Add metrics/logging for throttling.
- Avoid permanent account lockout from unauthenticated traffic.

### VOS-028 [P1] Cookie/origin/proxy security contract
- Define production web/API host topology.
- Configure trusted proxy behavior.
- Define trusted Origin policy and CSRF strategy for cookie-authenticated endpoints.

## Gate B - Reconcile architecture documents

### VOS-014 [P0] Documentation consistency gate
- Update SDD-03 with RefreshToken/session entity.
- Update SDD-04 table inventory and migration expectations.
- Update SDD-09 authentication mechanism.
- Update ADR-013 with active-tenant persistence and atomic rotation requirements.
- Add ADR-014 for Service/ServiceArea modeling.
- Update backlog statuses after each merged PR.

## Gate C - Business Configuration (next product milestone)

### VOS-040 [P1] Business profile API
### VOS-041 [P1] Locations API
### VOS-042 [P1] Services domain + API
### VOS-043 [P1] Service areas domain + API
### VOS-044 [P1] Business hours
### VOS-045 [P1] Custom field definitions
### VOS-046 [P1] Custom field values

**Milestone acceptance:** a remodeling tenant can be provisioned and fully configured without direct database edits.

## Gate D - CRM vertical slice

### VOS-050 [P1] Contacts
### VOS-051 [P1] Leads
### VOS-052 [P1] Lead sources
### VOS-053 [P1] Lead state transitions
### VOS-054 [P1] Lead assignment
### VOS-055 [P1] Minimal CRM dashboard

**Milestone acceptance:** a tenant can receive and manage a lead through the pre-AI pipeline with tenant isolation and audit coverage.

## Gate E - Events and queues before AI

Complete VOS-012 and then VOS-080 before building the AI agent layer.

The sequence should be:

```text
Business configuration
  -> CRM
  -> durable events
  -> queue execution
  -> conversations/provider abstraction
  -> AI provider abstraction
  -> tool framework
  -> workflow engine
  -> receptionist vertical slice
```

This prevents the LLM layer from becoming the orchestration layer.

## Recommended next 10 PRs

1. Atomic refresh rotation + concurrency test.
2. Active-tenant refresh persistence + tests.
3. Membership revocation/session invalidation use case.
4. Auth rate limiting + proxy/origin security configuration.
5. Documentation reconciliation + ADR-014.
6. Service and ServiceArea schema migration + RLS tests.
7. BusinessProfile + Location application/API layer.
8. Services + ServiceAreas application/API layer.
9. Contacts CRUD + tenant tests.
10. Leads + lifecycle state machine + audit.
