/// <reference path="../../../node_modules/.pnpm/@nuxt+nitro-server@4.5.2_lsohvpx52ur3egaqzitqmjcuy4/node_modules/@nuxt/nitro-server/dist/augments.d.mts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/shared-app.config.d.ts" />
/// <reference path="types/shared-imports.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
