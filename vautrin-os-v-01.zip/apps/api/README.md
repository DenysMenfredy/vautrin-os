# @vautrin/api

The Vautrin OS HTTP API — a NestJS modular monolith (VOS-004, ADR-002).

## Run

```bash
docker compose -f infra/docker-compose.yml up -d
pnpm db:deploy
pnpm --filter @vautrin/api dev
```

| Route | Purpose |
|---|---|
| `GET /api/health/live` | Liveness — touches no dependency |
| `GET /api/health/ready` | Readiness — verifies the database |
| `POST /api/auth/login` | Authenticate and issue short-lived access and rotating refresh tokens |
| `POST /api/auth/refresh` | Rotate a refresh token from the HttpOnly cookie or request body |
| `POST /api/auth/logout` | Revoke the refresh token in the HttpOnly cookie |
| `GET /api/auth/me` | Return the authenticated user, active tenant, role and capabilities |
| `POST /api/auth/tenant` | Switch active tenant for a verified membership |
| `GET /api/docs` | OpenAPI UI (non-production only) |
| `GET /api/docs-json` | OpenAPI document (non-production only) |

## Structure

```text
src/
  main.ts                      bootstrap: prefix, validation, filters, OpenAPI
  app.module.ts                composition root
  config/environment.module.ts validated environment, global
  database/                    DatabaseService — tenant-scoped data access
  health/                      liveness + readiness
  common/                      cross-cutting HTTP concerns
```

`app.module.ts` wires the implemented Auth, Tenant, Audit, Health, and Database
modules. Business, Contact, Lead, Conversation, Appointment, Estimate,
Workflow, Agent, Knowledge, Integration, and Analytics HTTP features are not
implemented yet.

## Authentication smoke tests

Open [`REST_COLLECTION`](./REST_COLLECTION) in Bruno and select its `Local API`
environment. Add an existing provisioned user's email and password in that
environment's local secret fields. If the user belongs to multiple tenants,
set `tenantId` to one of their membership IDs; otherwise the collection uses the
active tenant returned by login. The API has no public sign-up or demo-account
route.

Requests are ordered so **Run All** checks health and validation, then exercises
login, `/me`, tenant switching, body and cookie refresh, logout and refresh-token
revocation. API docs requests are for non-production environments only. Bruno
keeps access and refresh tokens as runtime variables and rotates the refresh
cookie between requests.

## Reaching the database

`DatabaseService.withTenant()` is the supported path:

```ts
const leads = await this.database.withTenant(tenantId, (tx) =>
  tx.lead.findMany({ where: { status: 'NEW' } }),
);
```

`.unscoped` exists for genuinely tenant-independent work — the readiness
probe, and the authentication lookup that must find a user before any tenant
is known. Tenant-scoped tables return zero rows through it, by design
(ADR-005).

Tenant context is never taken from client input. It is derived from
authenticated membership (SDD-05 §2); the resolver arrives with VOS-033.

## Conventions

**Validation.** A global `ValidationPipe` runs with `whitelist` and
`forbidNonWhitelisted`, so unknown properties are stripped and then rejected.
Endpoints take a DTO — that is what makes the rule enforceable.

**Errors.** `AllExceptionsFilter` gives every failure one shape. Unexpected
exceptions are logged in full and returned as a bare 500: stack traces and
driver errors are useless to a caller and useful to an attacker
(AGENTS.md §8).

**Shutdown.** Shutdown hooks are enabled so SIGTERM drains in-flight requests
and closes the database pool during a rolling deploy.

## Not here yet

Business-facing API modules and structured JSON logging with correlation IDs
(VOS-120) remain future work. The API currently uses Nest's default logger.
