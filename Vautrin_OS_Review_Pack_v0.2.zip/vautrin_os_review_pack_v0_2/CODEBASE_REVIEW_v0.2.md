# Vautrin OS Codebase Review - v0.2

## Review scope

This review compares the implementation in `vautrin-os-v-01` with the V0.1 SDDs, ADRs, AGENTS.md, and technical backlog.

The codebase is still foundation-heavy, which is appropriate at this stage. The strongest part of the implementation is the security-oriented multi-tenant foundation. The largest immediate risks are in refresh-token concurrency, active-tenant continuity during refresh, specification drift, and moving into business-domain features before closing the authentication edge cases.

## What is implemented well

### 1. Monorepo foundation matches the architecture

The repository follows the intended pnpm + Turborepo structure with separate `web`, `api`, and `worker` applications and shared packages. Build artifacts and dependencies are ignored by Git rather than tracked.

### 2. Multi-tenancy is treated as a security boundary

The implementation goes materially beyond a simple `tenant_id` filter:

- runtime and migration database roles are separated;
- tenant-scoped tables use PostgreSQL RLS;
- `FORCE ROW LEVEL SECURITY` is enabled;
- transaction-local `set_config` avoids tenant context leaking through pooled connections;
- an RLS coverage check guards against future tenant-scoped tables being added without policies;
- integration tests exercise cross-tenant SELECT/INSERT/UPDATE/DELETE and vector isolation.

This is aligned with ADR-003 and ADR-005 and is a strong foundation for the SaaS model.

### 3. Authentication design is substantially aligned with ADR-013

The code implements:

- Argon2id password verification;
- short-lived JWT access tokens;
- opaque refresh tokens;
- SHA-256 refresh-token digests at rest;
- refresh-token families;
- rotation and reuse detection;
- HttpOnly refresh cookies;
- active tenant switching with membership re-verification;
- capability-based RBAC.

### 4. CI/security posture is ahead of typical MVP quality

The repository includes linting, typechecking, unit/integration jobs, RLS assertions, Semgrep, dependency auditing, secret scanning, CodeQL configuration, and non-root container checks.

### 5. The code explains architectural intent

Comments consistently reference SDDs/ADRs and explain security-sensitive decisions. This is especially useful when coding agents participate in implementation.

## Findings requiring correction

### F-01 - P0 - Refresh rotation has a concurrency race

`RefreshTokenService.rotate()` first reads the token as valid and later performs an unconditional update inside a transaction. Two concurrent requests can both observe the predecessor as unused, both create successors, and both rotate successfully.

This violates the intended one-time-use property of refresh rotation.

**Required correction:** make token consumption atomic. The write that claims the predecessor must condition on `revoked_at IS NULL` and `replaced_by_id IS NULL` (or use an equivalent row-lock/serializable strategy). Exactly one request may succeed. A losing request should trigger the defined reuse policy.

Add a concurrency integration test that submits the same refresh token twice simultaneously and asserts that at most one successor becomes usable.

### F-02 - P0 - Active tenant is lost after refresh for multi-tenant users

`switchTenant()` issues an access token with a selected tenant, but the refresh token/session does not preserve that selection. `refresh()` chooses an active tenant only when the user has exactly one membership. A user with multiple memberships therefore becomes tenant-less after the access token expires.

**Required correction:** persist `active_tenant_id` in the server-side refresh session/token record, or require a requested tenant during refresh and re-verify membership. The preferred V0.2 design is to persist the active tenant on the refresh session and update it when tenant switching occurs.

### F-03 - P0 - Membership revocation is not an atomic security operation

`TenantService.revokeMembership()` changes membership state but only documents that refresh tokens must also be revoked. The method does not enforce that behavior itself.

**Required correction:** create an application use case for membership revocation that performs membership revocation plus relevant session-family revocation and audit. Do not expose the lower-level membership mutation directly as the complete security operation.

The 15-minute access-token stale window remains an explicit ADR trade-off unless sensitive routes add membership revalidation.

### F-04 - P1 - Authentication endpoints need abuse controls

The implementation protects against account enumeration but there is no documented rate-limit/lockout strategy for login and refresh endpoints.

**Required correction:** add rate limiting keyed by IP and normalized account identifier where appropriate, with observability and without creating a trivial account-lockout DoS.

### F-05 - P1 - Cookie security needs an explicit deployment/CSRF contract

The refresh token is correctly HttpOnly/Secure in production and `SameSite=Lax`, but the architecture does not yet define trusted origins, reverse-proxy behavior, CSRF handling, or the exact production host topology.

**Required correction:** document same-origin deployment as the preferred topology. Add trusted-origin checks/CSRF protection for cookie-authenticated state-changing endpoints as required by the final topology. Configure trusted proxy behavior before treating `request.ip` as the original client IP.

### F-06 - P1 - Specification drift already exists

The database SDD says its table set is exact, but the implementation added `refresh_tokens` through ADR-013. The backlog also says the database package contains four migrations while the repository contains six. This is expected during development, but the docs must remain the source of truth if coding agents are instructed to follow them.

**Required correction:** update SDD-03, SDD-04, SDD-09, ADR-013, and backlog metadata as part of this review pack.

### F-07 - P1 - Service and service-area modeling must be decided before E4

The backlog requires Services and Service Areas, but the current core schema has no dedicated `Service` or `ServiceArea` model. `Location.serviceRadiusMiles` is not sufficient for contractors serving multiple cities/ZIP codes, and services should not become arbitrary unvalidated JSON if they are used by qualification, analytics, and AI tools.

**Decision for V0.2:** add tenant-scoped `services` and `service_areas` tables before implementing VOS-042/VOS-043. Keep vertical templates responsible for seeding them.

### F-08 - P1 - Audit coverage is intentionally partial and should not be marked complete

Authentication/authorization audit behavior exists, but customer mutations, workflow activation, AI tools, and integration actions are not implemented yet. Keep VOS-121 IN_PROGRESS until those surfaces exist.

### F-09 - P2 - Global identity access deserves tighter infrastructure boundaries later

The runtime database role can access global identity/session tables because login occurs before tenant selection. Current code intentionally limits unscoped access through `DatabaseService`, but this remains an application-level convention for global tables.

For MVP this is acceptable. Before broader team access or plugin-like extensions, consider narrower database privileges or dedicated database functions/repositories for identity/session operations.

## Verification limitation

The repository was inspected directly. I could not execute the pnpm test suite in the review environment because the required pinned pnpm binary was not locally available and outbound package-registry access was unavailable. The repository itself contains CI definitions and generated build/test artifacts indicating active validation, but this review does not claim an independently executed green test run.

## Overall assessment

The implementation is directionally strong and consistent with the intended architecture. Do not start AI/workflow implementation yet. Close F-01 through F-06, then implement Business Configuration and CRM as the next product slice.
