const interopDefault = r => r.default || r || [];
const styles = {
  "../../../node_modules/.pnpm/nuxt@4.5.2_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typescrip_un7zymdosm7mo6x5qms2q5fwbi/node_modules/nuxt/dist/app/components/error-404.vue": () => import('../build/error-404-styles.CYwNIMFU.mjs').then(interopDefault),
  "../../../node_modules/.pnpm/nuxt@4.5.2_@babel+plugin-syntax-jsx@7.29.7_@babel+core@7.29.7__@babel+plugin-syntax-typescrip_un7zymdosm7mo6x5qms2q5fwbi/node_modules/nuxt/dist/app/components/error-500.vue": () => import('../build/error-500-styles.QFsZmm9z.mjs').then(interopDefault)
};

export { styles as default };
//# sourceMappingURL=styles.mjs.map
