/// <reference types="@nuxt/devtools" />
/// <reference types="@nuxt/telemetry" />
/// <reference path="types/nitro-layouts.d.ts" />
/// <reference path="types/modules.d.ts" />
/// <reference path="types/runtime-config.d.ts" />
/// <reference path="types/shared-app.config.d.ts" />
/// <reference types="nuxt" />
/// <reference path="../../../node_modules/.pnpm/@nuxt+vite-builder@4.5.2_aawgey7xqahkybjuuhk7me3xom/node_modules/@nuxt/vite-builder/dist/index.d.mts" />
/// <reference path="../../../node_modules/.pnpm/@nuxt+nitro-server@4.5.2_lsohvpx52ur3egaqzitqmjcuy4/node_modules/@nuxt/nitro-server/dist/augments.d.mts" />
/// <reference path="types/nitro-middleware.d.ts" />
/// <reference path="schema/nuxt.schema.d.ts" />

export {}
