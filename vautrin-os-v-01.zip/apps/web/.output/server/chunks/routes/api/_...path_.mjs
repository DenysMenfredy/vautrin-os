import { d as defineEventHandler, u as useRuntimeConfig, g as getRouterParam, a as getRequestURL, c as createError, p as proxyRequest } from '../../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

function hasTraversalSegment(path) {
  let decoded = path;
  for (let i = 0; i < 3; i += 1) {
    let next;
    try {
      next = decodeURIComponent(decoded);
    } catch {
      return true;
    }
    if (next === decoded) break;
    decoded = next;
  }
  return decoded.split(/[/\\]/).some((segment) => segment === ".." || segment === ".");
}
const ____path_ = defineEventHandler((event) => {
  var _a;
  const { apiInternalBase } = useRuntimeConfig(event);
  const path = (_a = getRouterParam(event, "path")) != null ? _a : "";
  const query = getRequestURL(event).search;
  if (hasTraversalSegment(path)) {
    throw createError({ statusCode: 400, statusMessage: "Invalid API path" });
  }
  const base = new URL(apiInternalBase.endsWith("/") ? apiInternalBase : `${apiInternalBase}/`);
  const target = new URL(path, base);
  if (target.origin !== base.origin || !target.pathname.startsWith(base.pathname)) {
    throw createError({ statusCode: 400, statusMessage: "Invalid API path" });
  }
  return proxyRequest(event, `${target.href}${query}`);
});

export { ____path_ as default };
//# sourceMappingURL=_...path_.mjs.map
